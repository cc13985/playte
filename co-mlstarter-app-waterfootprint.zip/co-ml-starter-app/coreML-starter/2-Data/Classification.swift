//
//  Classification.swift
//  coreML-starter
//
//  
//

struct Classification: Decodable {
    // TODO: replace with the name of your keys from mydata.json and some default values
    var label: String = "carrot"
    var water: Int = 5
    var emoji: String = "🥕"
}
