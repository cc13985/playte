//
//  AboutView.swift
//  coreML-starter
//
//

import SwiftUI

struct AboutView: View {
    
    var body: some View {
        VStack {
            Text("Add some info about who created the app!")
        }
    }
}
