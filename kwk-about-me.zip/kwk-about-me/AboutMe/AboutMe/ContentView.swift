//
//  ContentView.swift
//  AboutMe
//
//

import SwiftUI

struct ContentView: View {
    @StateObject var viewModel = ViewModel()
    @State var dataToLoad: Scholar = Scholar(name: "Tiffany", snack: "mochi", animal: "🐢")
    
    var body: some View {
        // Example with Hard-coded Data (Scholars can start with here to learn about Text fields, stacks before learning about JSON)
        
        /*
        VStack {
            Text("Tiffany")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()

            HStack {
                Text("Favorite snack: ")
                    .fontWeight(.bold)
                Text("mochi")
            }
            .padding()

            HStack {
                Text("Favorite animal: ")
                    .fontWeight(.bold)
                Text("🐢")
            }
        }
        */
        
        
        // Example with JSON Data - Can use this example when showing how you can load data from JSON in your app
        
        VStack {
            Text(dataToLoad.name)
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()

            HStack {
                Text("Favorite snack: ")
                    .fontWeight(.bold)
                Text(dataToLoad.snack)
            }
            .padding()

            HStack {
                Text("Favorite animal: ")
                    .fontWeight(.bold)
                Text(dataToLoad.animal)
            }
            .padding()

            Button(action: {
                viewModel.changeIndex()
                dataToLoad = viewModel.scholarData[viewModel.currentIndex]
            }){
                Text("Next Scholar")
            }
            .buttonStyle(RoundedRectButtonStyle())
            .padding()
        }
        .onAppear{
            viewModel.loadJSON()
            dataToLoad = viewModel.scholarData[viewModel.currentIndex]
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
