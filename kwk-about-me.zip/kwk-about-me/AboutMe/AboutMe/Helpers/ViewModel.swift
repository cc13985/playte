//
//  ViewModel.swift
//  AboutMe
//
//

import Foundation

final class ViewModel: ObservableObject {
    @Published var scholarData: [Scholar] = []
    @Published var currentIndex = 0
    
    func loadJSON() {
        if let url = Bundle.main.url(forResource: "data", withExtension: "json") {
            do {
                let jsonData = try Data(contentsOf: url)
                let decoder = JSONDecoder()
                scholarData = try decoder.decode([Scholar].self, from: jsonData)
            } catch {
                print(error)
            }
        } else {
        }
    }
    
    func changeIndex() {
        if (currentIndex < scholarData.count-1) {
            currentIndex = currentIndex + 1
        } else {
            currentIndex = 0
        }
    }
}
