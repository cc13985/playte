//
//  Scholar.swift
//  AboutMe
//
//

struct Scholar: Decodable {
    var name: String
    var snack: String
    var animal: String
}
